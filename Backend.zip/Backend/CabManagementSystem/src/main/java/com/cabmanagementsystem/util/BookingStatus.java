package com.cabmanagementsystem.util;

public enum BookingStatus {

	PENDING, CONFIRMED, CANCELED
}
