package com.cabmanagementsystem.util;

public enum RideStatus {

	SCHEDULED, ONGOING, COMPLETED, CANCELED
}
